import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import joblib
import time
import logging

# Set up logging
logging.basicConfig(filename='smartids.log', level=logging.INFO, format='%(asctime)s %(message)s')

# Load training and testing datasets
train_data = pd.read_csv("H:/python/SmartIDS/KDDTrain.csv")
test_data = pd.read_csv("H:/python/SmartIDS/KDDTest.csv")

# Ensure 'attack_class' column exists
if 'attack_class' not in train_data.columns or 'attack_class' not in test_data.columns:
    raise KeyError("The column 'attack_class' is not found in the dataset. Please check the dataset.")

# Encode categorical features for training data
encoders = {'protocol_type': LabelEncoder(), 'service': LabelEncoder(), 'flag': LabelEncoder()}
for col, encoder in encoders.items():
    train_data[col] = encoder.fit_transform(train_data[col])
    test_data[col] = encoder.transform(test_data[col])

# Split features and labels for training and testing data
X_train, y_train = train_data.drop('attack_class', axis=1), train_data['attack_class']
X_test, y_test = test_data.drop('attack_class', axis=1), test_data['attack_class']

# Normalize numerical features
scaler = StandardScaler()
num_features = ['duration', 'src_bytes', 'dst_bytes']
X_train[num_features] = scaler.fit_transform(X_train[num_features])
X_test[num_features] = scaler.transform(X_test[num_features])

# Train a random forest classifier for feature selection
feature_selection_model = RandomForestClassifier()
feature_selection_model.fit(X_train, y_train)
importances = feature_selection_model.feature_importances_

# Select top 20 features based on importance
selected_features = pd.Series(importances, index=X_train.columns).nlargest(20).index
X_train_selected, X_test_selected = X_train[selected_features], X_test[selected_features]

# Train the Random Forest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train_selected, y_train)

# Make predictions and evaluate the model
y_pred = model.predict(X_test_selected)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred, zero_division=0))

# Save the trained model
joblib.dump(model, 'smartids_model.pkl')
loaded_model = joblib.load('smartids_model.pkl')

# Function to simulate real-time network data collection
def get_new_network_data():
    return X_test_selected.sample(1)

# Function to preprocess new data
def preprocess_data(new_data):
    return new_data[selected_features]

# Function to alert the system administrator
def alert_admin():
    logging.info("ALERT: Malicious activity detected!")

# Function to monitor network in real-time
def monitor_network():
    while True:
        new_data = get_new_network_data()
        new_data_processed = preprocess_data(new_data)
        prediction = loaded_model.predict(new_data_processed)
        if prediction[0] == 'malicious':
            alert_admin()
        time.sleep(1)

# Start monitoring the network
monitor_network()
